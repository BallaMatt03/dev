
import java.io.File;
import java.io.FileOutputStream;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.io.*;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

public class ClasseTP2 {
	
	static OWLOntology ont1, ont2;
	
	public static void main(String[] args) throws Exception {
		
		System.out.println("Bonjour");
		
		maFonction();
		
		maDeuxiemeFonction();
		}
	
	public static void maFonction() throws Exception {	
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		
		File inputOntologyFile1 = new File("TP_2/TP2/TP2/GRO.xml");
		ont1 = manager.loadOntologyFromOntologyDocument(inputOntologyFile1);
		
		IRI doc = IRI.create("file:/home/matthias/Dropbox/dev/work/ia_resolution_contraintes/TP_2/TP2/TP2//validGCIs.xml");
		ont2 = manager.createOntology();
		manager.saveOntology(ont2, new OWLXMLOntologyFormat(), doc);
		
	}
	
	public static void maDeuxiemeFonction() throws Exception
	{
		//OWLReasonerFactory reasonerFactory = null;
		//OWLReasoner reasoner = reasonerFactory.createNonBufferingReasoner(ont1);
		OWLDataFactory dataFactory = manager.getOWLDataFactory();
		File gcis = new File("TP_2/TP2/TP2/gcis");
		/*
		 * OWLAxiom axiom = ...
		 * 
		 */
		
		OWLAxiom axiom=dataFactory.getOWLSubClassOfAxiom(margherita, hasToppingMozarellaOrGoatsCheese);
		
		
	}

}
