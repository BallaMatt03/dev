/* ---------------------- */
/* --- motionNR_SSE.c --- */
/* ---------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

#include "def.h"
#include "nrutil.h"
#include "timers_b.h"

#include "vdef.h"
#include "vnrutil.h"

#include "morphoNR_SSE.h"
#include "motionNR_SSE.h"

#ifdef OPENMP
#include <omp.h>
#endif
/*
#include <ia32intrin.h>

double dtime()
{
    return (double) _rdtsc();
}
*/ 
// ---------------------------------------------------------------------------
void PreProcessing_SSE(vuint8 **X, vuint8 **Y, int i0, int i1, int j0, int j1)
// ---------------------------------------------------------------------------
{
    // simple copie pour assurer le fonctionnement du programme principal
    dup_vui8matrix(X, i0, i1, j0, j1, Y);
    // A COMPLETER
}
// ----------------------------------------------------------------------------
void PostProcessing_SSE(vuint8 **X, vuint8 **Y, int i0, int i1, int j0, int j1)
// ----------------------------------------------------------------------------
{
    vuint8 **T;
    T = NULL;
    
    // simple copie pour assurer le fonctionnement du programme principal
    dup_vui8matrix(X, i0, i1, j0, j1, Y);
    // A COMPLETER
}
// ----------------------------------------------------------------------------------------------------------------------------------
void FrameDifference_FirstStep_SSE(vuint8 **I0, vuint8 **I1, vuint8 **D, vuint8 **S, uint8 threshold, int i0, int i1, int j0, int j1)
// ----------------------------------------------------------------------------------------------------------------------------------
{
    int i,j;   
    vuint8 zero;
    
    zero = _mm_set1_epi8(0);
    
    for(i=i0; i<=i1; i++) {
        for(j=j0; j<=j1; j++) {
            _mm_store_si128(&D[i][j], zero);
            _mm_store_si128(&S[i][j], zero);
        }
    }
}
// ------------------------------------------------------------------------------------------------------------------------------
void FrameDifference_1Step_SSE(vuint8 **I0, vuint8 **I1, vuint8 **D, vuint8 **S, uint8 threshold, int i0, int i1, int j0, int j1)
// ------------------------------------------------------------------------------------------------------------------------------
{
    int i,j;
    
    vuint8 x0, x1, o, e;
    vuint8 vmax, vmin, gt;
    vuint8 vthreshold;
    vuint8 k128;
    vuint8 one;
    
    vuint8 o_128, vthreshold_128;
   
    vthreshold     = _mm_set1_epi8(threshold-1);
    k128           = _mm_set1_epi8(128);
    one            = _mm_set1_epi8(1);
    vthreshold_128 = _mm_sub_epi8(vthreshold, k128);

#ifdef OPENMP
#pragma omp parallel for private(j)
#endif
    for(i=i0; i<=i1; i++) {
        for(j=j0; j<=j1; j++) {
            
            // load
            x0 = _mm_load_si128(&I0[i][j]);
            x1 = _mm_load_si128(&I1[i][j]);
            
            // A COMPLETER

            // store
            _mm_store_si128(&D[i][j], o);
            _mm_store_si128(&S[i][j], e);
        }
    }
}
// ------------------------------------------------------------------------------------------------------------------------------
void SigmaDelta_FirstStep_SSE(vuint8 **I, vuint8 **M, vuint8 **O, vuint8 **V, vuint8 **E, int k, int i0, int i1, int j0, int j1)
// ------------------------------------------------------------------------------------------------------------------------------
{
    int i,j;
    
    vuint8 x;
    vuint8 zero;
    vuint8 one;
    
    zero = _mm_set1_epi8(0);
    one  = _mm_set1_epi8(1);

    for(i=i0; i<=i1; i++) {
        for(j=j0; j<=j1; j++) {
            
            // load
            x = _mm_load_si128(&I[i][j]);
                       
            // store
            _mm_store_si128(&M[i][j], x);
            _mm_store_si128(&O[i][j], zero);
            _mm_store_si128(&V[i][j], one);
            _mm_store_si128(&E[i][j], zero);
        }
    }
}
// -------------------------------------------------------------------------------------------------------------------------
void SigmaDelta_1Step_SSE(vuint8 **I, vuint8 **M, vuint8 **O, vuint8 **V, vuint8 **E, int k, int i0, int i1, int j0, int j1)
// -------------------------------------------------------------------------------------------------------------------------
{
    /*#ifdef OPENMP
    //#pragma omp parallel default(none) shared(I, M, O, V, E, i0,i1,j0,j1,k)
    #pragma omp parallel shared(I, M, O, V, E, i0,i1,j0,j1,k)
	{
    #endif*/


    int i,j;
    
    vuint8 x, m, o, v, e;
    vuint8 x128, m128, o128, v128, k128, ko128;
    vuint8 zero;
    vuint8 one;
    vuint8 lt, gt;
    vuint8 ko;
    vuint8 inc, z; // zero flag
  
    zero = _mm_set1_epi8(0);
    one  = _mm_set1_epi8(1);

    k128 = _mm_set1_epi8(128);

#ifdef OPENMP
//#pragma omp parallel for private(j)
    #pragma omp parallel for private(i, j, x, m, o, v, e, x128, m128, o128, v128, k128, ko128, zero, one, lt, gt, ko, inc, z)
#endif
    for(i=i0; i<=i1; i++) {
        for(j=j0; j<=j1; j++) {
            
            // load
            x = _mm_load_si128(&I[i][j]);
            m = _mm_load_si128(&M[i][j]);
            v = _mm_load_si128(&V[i][j]);

            
            // A COMPLETER
                                   
            // store
            _mm_store_si128(&M[i][j], m);
            _mm_store_si128(&O[i][j], o);
            _mm_store_si128(&V[i][j], v);
            _mm_store_si128(&E[i][j], e);

        }
    }

    //#ifdef OPENMP
	//}
    //#endif
}
