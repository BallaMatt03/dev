#include <iostream>
#include <string>
#include "distance.hpp"
#include "pixel.hpp"
#include "bizarro.hpp"

template<typename Point>
void foo(Point const& p)
{
  coord_t<pixel,0> px = at(p,0);
  coord_t<pixel,1> py = at(p,1);
}

int main()
{
  pointND<double> p{1.,1.,1.};
  pointND<double> q(3);
  pixel a{3,4},b{1,-3};
  bizarro_point wuz{3,0.5,'Z'};

  std::array<float,5> xx{1,2,3,4,5};
  std::array<float,5> yy{-1,-2,-3,-4,-5};
  point2D<double> q2{68,4};

  coord_t<pixel> px = at(a,0);
  coord_t<pixel> py = at(a,1);
  // std::cout << px << " " << py << "\n";
  // std::cout << at<3>(xx) << "\n";
  // std::cout << at<0>(q2) << "\n";

  std::cout << at(wuz,0) << "\n";
  std::cout << at(wuz,1) << "\n";
  std::cout << at(wuz,2) << "\n";
  std::cout << at<0>(wuz) << "\n";
  std::cout << at<1>(wuz) << "\n";
  std::cout << at<2>(wuz) << "\n";
  std::cout << at<-2>(wuz) << "\n";

/*
  std::cout << q.size() << "\n";
  std::cout << p[0] << "\n";
  std::cout << p[1] << "\n";
  std::cout << p[2] << "\n";
  std::cout << distance(p,q) << "\n";
  std::cout << distance(q2,q) << "\n";
  std::cout << distance("lol!","rofl") << "\n";
  std::cout << distance(a,b) << "\n";
  std::cout << distance(xx,yy) << "\n";
  std::cout << distance(xx,a) << "\n";
  */
}
